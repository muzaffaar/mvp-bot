<?php

namespace App\Http\Controllers\Task;

use App\Enums\TaskStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Task\AssignTaskRequest;
use App\Http\Requests\Task\ChangeTaskStatusRequest;
use App\Http\Requests\Task\StoreTaskRequest;
use App\Http\Requests\Task\UpdateTaskRequest;
use App\Models\Staff;
use App\Models\Task;
use App\Services\Task\TaskService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function __construct(
        private readonly TaskService $taskService,
    ) {
    }

    public function index(Request $request)
    {
        $tasks = Task::query()
            ->with([
                'author',
                'assignor',
                'assignee',

                // Task relations
                'logs',
                'comments',
                'sprints',

                // Self-referencing relations
                'authoredTasks',
                'assignedTasks',
                'assignedByTasks',

                // Efficiency
                // 'efficiencies',

                // Sprints created by the task's author
                'createdSprints',
            ])
            ->get();

        return view('tasks.index', compact('tasks'));
    }

    public function store(
        StoreTaskRequest $request
    ): JsonResponse {
        /** @var Staff $staff */
        $staff = $request->user();

        $task = $this->taskService->create(  
            data: $request->validated(),
            actor: $staff,
        );

        return response()->json([
            'message' => 'Task created successfully.',
            'data' => $task,
        ], 201);
    }

    public function show(Task $task)
    {
        $task->load([
            'author',
            'assignor',
            'assignee',
            'logs',
            'comments.staff',
            'sprints',
        ]);

        return view('tasks.show', compact('task'));
    }

    public function update(
        UpdateTaskRequest $request,
        Task $task
    ): JsonResponse {
        /** @var Staff $staff */
        $staff = $request->user();

        $task = $this->taskService->update(
            task: $task,
            data: $request->validated(),
            actor: $staff,
        );

        return response()->json([
            'message' => 'Task updated successfully.',
            'data' => $task,
        ]);
    }

    public function assign(
        AssignTaskRequest $request,
        Task $task
    ): JsonResponse {
        /** @var Staff $actor */
        $actor = $request->user();

        $assignee = Staff::findOrFail(
            $request->integer('assignee_id')
        );

        $task = $this->taskService->assign(
            task: $task,
            assignee: $assignee,
            actor: $actor,
        );

        return response()->json([
            'message' => 'Task assigned successfully.',
            'data' => $task,
        ]);
    }

    public function reassign(
        AssignTaskRequest $request,
        Task $task
    ): JsonResponse {
        /** @var Staff $actor */
        $actor = $request->user();

        $assignee = Staff::findOrFail(
            $request->integer('assignee_id')
        );

        $task = $this->taskService->reassign(
            task: $task,
            assignee: $assignee,
            actor: $actor,
            reason: $request->input('reason'),
        );

        return response()->json([
            'message' => 'Task reassigned successfully.',
            'data' => $task,
        ]);
    }

    public function changeStatus(
        ChangeTaskStatusRequest $request,
        Task $task
    ): JsonResponse {
        /** @var Staff $actor */
        $actor = $request->user();

        $task = $this->taskService->changeStatus(
            task: $task,
            newStatus: TaskStatus::from(
                $request->input('status')
            ),
            actor: $actor,
            comment: $request->input('comment'),
        );

        return response()->json([
            'message' => 'Task status changed successfully.',
            'data' => $task,
        ]);
    }

    public function destroy(
        Request $request,
        Task $task
    ): JsonResponse {
        abort_unless(
            $request->user()?->can('tasks.delete'),
            403
        );

        /** @var Staff $staff */
        $staff = $request->user();

        $this->taskService->delete(
            task: $task,
            actor: $staff,
        );

        return response()->json([
            'message' => 'Task deleted successfully.',
        ]);
    }

    public function accept(
        Request $request,
        Task $task
    ): JsonResponse {
        /** @var Staff $staff */
        $staff = $request->user();

        $task = $this->taskService->accept(
            task: $task,
            staff: $staff,
        );

        return response()->json([
            'message' => 'Task accepted successfully.',
            'data' => $task,
        ]);
    }
}
